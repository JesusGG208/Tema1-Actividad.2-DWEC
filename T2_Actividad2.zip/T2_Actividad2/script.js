/* Ejercicio 1 */
/*
let gastosAlojamiento = parseFloat(prompt("Introduzca el coste de alojamiento: ")).toFixed(2);
let gastosAlimentacion = parseFloat(prompt("Introduzca el coste de alimentación: ")).toFixed(2);
let gastosEntretenimiento = parseFloat(prompt("Introduzca el coste de entretenimiento: ")).toFixed(2);

let costeTotal = gastosAlojamiento + gastosAlimentacion + gastosEntretenimiento;

console.log("El coste total es " + costeTotal.toFixed(2) + " €");
*/
/* EJercicio 2 */

/*
let edadPerro = parseInt(prompt("Introduzca la edad del perro: "));
let edadHumano = 7 * edadPerro;

console.log("La edad del perro en años humano es " + edadHumano + " años")
*/
/* EJercicio 3 */
/*
let peso = parseFloat(prompt("Introduzca el peso (kg) de su persona: "));
let altura = parseFloat(prompt("Introduzca la altura (m) de su persona: "));

let imc = (peso / (altura ** 2));

if (imc < 18.5) {
    console.log("Infrapeso");
} else if (imc >= 18.5 && imc < 25) {
    console.log("Peso normal");
} else if (imc >= 25 && imc < 30) {
    console.log("Sobrepeso");
} else if(imc >= 30) {
    console.log("Obesidad");
}
*/
/* EJercicio 4 */
